import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sthis',
  templateUrl: './sthis.component.html',
  styleUrls: ['./sthis.component.css']
})
export class SthisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
