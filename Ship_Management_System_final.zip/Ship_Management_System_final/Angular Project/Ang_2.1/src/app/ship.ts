export class Ship {
    regId:number=0
    email: string=""
    name: string=""
    addr: string=""
    userId: string=""
    empAtt: boolean=false
    resrv: string=""
    pass: string=""
    phon: string=""
    tskDtl: string=""
    tskSts: boolean=false
    itmInstSts: boolean=false
    eqmtNm: string=""
    itmPrc: number=0
    prchsId: string=""
    pep:number=0
    god:number=0
}
