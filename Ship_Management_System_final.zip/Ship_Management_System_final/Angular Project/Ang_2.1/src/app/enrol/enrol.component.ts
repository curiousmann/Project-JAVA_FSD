import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enrol',
  templateUrl: './enrol.component.html',
  styleUrls: ['./enrol.component.css']
})
export class EnrolComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
