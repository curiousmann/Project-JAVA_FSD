import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-embill',
  templateUrl: './embill.component.html',
  styleUrls: ['./embill.component.css']
})
export class EmbillComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
