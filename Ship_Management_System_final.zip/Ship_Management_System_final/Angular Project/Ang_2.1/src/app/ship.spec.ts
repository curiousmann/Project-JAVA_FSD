import { Ship } from './ship';

describe('Ship', () => {
  it('should create an instance', () => {
    expect(new Ship()).toBeTruthy();
  });
});
