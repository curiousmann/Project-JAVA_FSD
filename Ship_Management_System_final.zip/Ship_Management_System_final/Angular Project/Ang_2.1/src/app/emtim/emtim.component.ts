import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emtim',
  templateUrl: './emtim.component.html',
  styleUrls: ['./emtim.component.css']
})
export class EmtimComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
